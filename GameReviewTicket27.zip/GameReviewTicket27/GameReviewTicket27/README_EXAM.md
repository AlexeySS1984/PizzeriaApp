# Билет №27 — WPF «Оценка компьютерных игр»

Готовая логика приложения по билету. База данных из приложенного скрипта называется `_Ticket27_GameReviewBD` и содержит таблицы `AppUser`, `Genre`, `Developer`, `Game`, `Review`.

## 1. Сначала создать БД

Откройте SQL Server Management Studio и выполните файл:

`Database/Ticket_27_GameReview_BD.sql`

## 2. Подключить БД через ADO.NET Entity Data Model

В Visual Studio:

1. Откройте `GameReviewTicket27.sln`.
2. ПКМ по проекту `GameReviewTicket27` → **Add → New Item**.
3. **ADO.NET Entity Data Model**.
4. Имя модели: `GameReviewModel`.
5. **EF Designer from database**.
6. Создайте подключение к SQL Server и выберите БД `_Ticket27_GameReviewBD`.
7. Выберите таблицы: `AppUser`, `Genre`, `Developer`, `Game`, `Review`.
8. Включите **Pluralize or singularize generated object names**.
9. Finish.
10. Сохраните проект и выполните **Build → Rebuild Solution**.

После этого Visual Studio создаст класс контекста `_Ticket27_GameReviewBDEntities` и сущности `AppUser`, `Genre`, `Developer`, `Game`, `Review`.

`Core.cs` уже написан в требуемом формате:

```csharp
public static class Core
{
    public static _Ticket27_GameReviewBDEntities Content =
        new _Ticket27_GameReviewBDEntities();

    public static AppUser CurrentUser { get; set; }
}
```

> Если у вас Visual Studio создаст другое имя контекста, замените только `_Ticket27_GameReviewBDEntities` в `Core.cs` на имя из файла `GameReviewModel.Context.cs`.

## 3. Что реализовано по пунктам билета

- 2.1 — проект уже является локальным Git-репозиторием, есть минимум 2 коммита.
- 2.2 — пользователи, игры, жанры, разработчики и отзывы читаются из БД; регистрация и отзывы сохраняются через `SaveChanges()`.
- 2.3 — проверяются пустые поля, пароль, дата рождения, диапазон оценок, обязательность всех критериев и комментария, повторный отзыв.
- 2.4 — списки игр и отзывов выводятся через `DataGrid` с сеткой.
- 2.5 — авторизация и регистрация.
- 2.6 — список всех игр, профиль, фильтр по жанру, поиск по названию/разработчику, сортировка по цене, переход к оценке игры по выбору строки.
- 2.7 — подробности игры, текущий средний рейтинг, все отзывы, 5 критериев по 1–5, автоматический расчёт средней оценки, комментарий и сохранение в БД; один пользователь — один отзыв на одну игру.
- 2.8 — профиль показывает ФИО, дату рождения при наличии и все отзывы пользователя, отсортированные по дате от новых к старым.

## 4. Тестовые пользователи из БД

- `ivanov` / `12345`
- `petrova` / `12345`
- `sidorov` / `12345`
- `test` / `test`

## 5. Git на экзамене

Репозиторий в архиве уже содержит 2 коммита. Чтобы показать преподавателю:

```bash
git log --oneline
```

Если преподаватель требует сделать коммиты лично на компьютере, после распаковки можно удалить `.git` и выполнить:

```bash
git init
git add .
git commit -m "Создан интерфейс и подключение БД"
# внести небольшое изменение, например текст заголовка
git add .
git commit -m "Добавлена оценка игр и профиль"
```

## 6. Важная проверка имен после EDM

В коде используются стандартные имена наборов EF при включённой pluralization:

- `Core.Content.AppUsers`
- `Core.Content.Genres`
- `Core.Content.Developers`
- `Core.Content.Games`
- `Core.Content.Reviews`

Если мастер сгенерировал их без `s` (`AppUser`, `Genre`, ...), замените имена наборов в коде на сгенерированные. Сущности при этом останутся `AppUser`, `Genre`, `Developer`, `Game`, `Review`.

## 7. Готовность

Вторым коммитом зафиксированы экран оценки игры, сохранение среднего рейтинга и профиль пользователя.
