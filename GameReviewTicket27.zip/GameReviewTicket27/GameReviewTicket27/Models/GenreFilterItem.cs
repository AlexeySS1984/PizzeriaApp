namespace GameReviewTicket27.Models
{
    public class GenreFilterItem
    {
        public int? ID { get; set; }
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
