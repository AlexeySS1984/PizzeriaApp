using System;

namespace GameReviewTicket27.Models
{
    public class UserReviewRow
    {
        public string GameName { get; set; }
        public decimal AvgRating { get; set; }
        public string Comment { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
