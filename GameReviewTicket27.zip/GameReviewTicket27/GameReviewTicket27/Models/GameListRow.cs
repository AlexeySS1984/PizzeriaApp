namespace GameReviewTicket27.Models
{
    public class GameListRow
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Genre { get; set; }
        public string Developer { get; set; }
        public decimal Price { get; set; }
        public decimal Rating { get; set; }
        public int ReviewCount { get; set; }
    }
}
