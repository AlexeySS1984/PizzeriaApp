using System;

namespace GameReviewTicket27.Models
{
    public class ReviewRow
    {
        public string UserFIO { get; set; }
        public decimal AvgRating { get; set; }
        public byte Gameplay { get; set; }
        public byte Graphics { get; set; }
        public byte Story { get; set; }
        public byte Sound { get; set; }
        public byte Optimization { get; set; }
        public string Comment { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
