using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using GameReviewTicket27.Models;

namespace GameReviewTicket27.Pages
{
    public partial class ProfilePage : Page
    {
        public ProfilePage()
        {
            InitializeComponent();
            LoadProfile();
        }

        private void LoadProfile()
        {
            if (Core.CurrentUser == null)
            {
                MessageBox.Show("Сначала выполните вход.");
                NavigationService.Navigate(new AuthPage());
                return;
            }

            FioTextBlock.Text = "ФИО: " + Core.CurrentUser.FIO;
            LoginTextBlock.Text = "Логин: " + Core.CurrentUser.Login;
            BirthdayTextBlock.Text = Core.CurrentUser.Birthday.HasValue
                ? "Дата рождения: " + Core.CurrentUser.Birthday.Value.ToString("dd.MM.yyyy")
                : "Дата рождения: не указана";

            try
            {
                List<UserReviewRow> reviews = Core.Content.Reviews
                    .Where(r => r.AppUserID == Core.CurrentUser.ID)
                    .OrderByDescending(r => r.CreatedAt)
                    .Select(r => new UserReviewRow
                    {
                        GameName = r.Game.Name,
                        AvgRating = r.AvgRating,
                        Comment = r.Comment,
                        CreatedAt = r.CreatedAt
                    }).ToList();

                UserReviewsDataGrid.ItemsSource = reviews;
                ReviewCountTextBlock.Text = "Количество отзывов: " + reviews.Count;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки профиля: " + ex.Message);
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new GamesPage());
        }
    }
}
