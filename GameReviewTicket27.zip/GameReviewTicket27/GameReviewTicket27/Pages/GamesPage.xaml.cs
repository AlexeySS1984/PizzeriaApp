using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using GameReviewTicket27.Models;

namespace GameReviewTicket27.Pages
{
    public partial class GamesPage : Page
    {
        private bool _isLoaded;
        private bool _navigating;

        public GamesPage()
        {
            InitializeComponent();

            if (Core.CurrentUser == null)
            {
                NavigationService.LoadCompleted += delegate { NavigationService.Navigate(new AuthPage()); };
                return;
            }

            UserTextBlock.Text = Core.CurrentUser.FIO;
            LoadGenres();
            _isLoaded = true;
            LoadData();
        }

        private void LoadGenres()
        {
            List<GenreFilterItem> items = new List<GenreFilterItem>();
            items.Add(new GenreFilterItem { ID = null, Name = "Все жанры" });

            items.AddRange(Core.Content.Genres
                .OrderBy(g => g.Name)
                .Select(g => new GenreFilterItem
                {
                    ID = g.ID,
                    Name = g.Name
                }).ToList());

            GenreComboBox.ItemsSource = items;
            GenreComboBox.SelectedIndex = 0;
        }

        private void LoadData()
        {
            if (!_isLoaded)
                return;

            try
            {
                var games = Core.Content.Games.AsQueryable();

                string search = SearchTextBox.Text.Trim();
                if (!string.IsNullOrWhiteSpace(search))
                {
                    games = games.Where(g =>
                        g.Name.Contains(search) ||
                        g.Developer.Name.Contains(search));
                }

                GenreFilterItem genre = GenreComboBox.SelectedItem as GenreFilterItem;
                if (genre != null && genre.ID.HasValue)
                {
                    int genreId = genre.ID.Value;
                    games = games.Where(g => g.GenreID == genreId);
                }

                if (SortComboBox.SelectedIndex == 1)
                {
                    games = games.OrderBy(g => g.Price);
                }
                else if (SortComboBox.SelectedIndex == 2)
                {
                    games = games.OrderByDescending(g => g.Price);
                }
                else
                {
                    games = games.OrderBy(g => g.Name);
                }

                List<GameListRow> result = games.Select(g => new GameListRow
                {
                    ID = g.ID,
                    Name = g.Name,
                    Genre = g.Genre.Name,
                    Developer = g.Developer.Name,
                    Price = g.Price,
                    Rating = g.Reviews.Select(r => (decimal?)r.AvgRating).Average() ?? 0m,
                    ReviewCount = g.Reviews.Count()
                }).ToList();

                GamesDataGrid.ItemsSource = result;
                GamesDataGrid.SelectedItem = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки списка игр: " + ex.Message);
            }
        }

        private void SearchTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadData();
        }

        private void GenreComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadData();
        }

        private void SortComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadData();
        }

        private void GamesDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (_navigating)
                return;

            GameListRow selected = GamesDataGrid.SelectedItem as GameListRow;
            if (selected == null)
                return;

            _navigating = true;
            NavigationService.Navigate(new GameReviewPage(selected.ID));
        }

        private void ProfileButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ProfilePage());
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            Core.CurrentUser = null;
            NavigationService.Navigate(new AuthPage());
        }
    }
}
