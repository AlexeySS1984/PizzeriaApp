using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using GameReviewTicket27.Models;

namespace GameReviewTicket27.Pages
{
    public partial class GameReviewPage : Page
    {
        private readonly int _gameId;

        public GameReviewPage(int gameId)
        {
            InitializeComponent();
            _gameId = gameId;

            List<int> values = new List<int> { 1, 2, 3, 4, 5 };
            GameplayComboBox.ItemsSource = values;
            GraphicsComboBox.ItemsSource = values;
            StoryComboBox.ItemsSource = values;
            SoundComboBox.ItemsSource = values;
            OptimizationComboBox.ItemsSource = values;

            LoadGame();
            LoadReviews();
            CheckExistingReview();
        }

        private void LoadGame()
        {
            try
            {
                Game game = Core.Content.Games.FirstOrDefault(g => g.ID == _gameId);
                if (game == null)
                {
                    MessageBox.Show("Игра не найдена.");
                    NavigationService.Navigate(new GamesPage());
                    return;
                }

                decimal rating = Core.Content.Reviews
                    .Where(r => r.GameID == _gameId)
                    .Select(r => (decimal?)r.AvgRating)
                    .Average() ?? 0m;

                GameNameTextBlock.Text = game.Name;
                GameRatingTextBlock.Text = rating == 0m ? "Нет оценок" : rating.ToString("F2") + " / 5";
                DeveloperTextBlock.Text = game.Developer.Name;
                PriceTextBlock.Text = game.Price.ToString("N2") + " ₽";
                DescriptionTextBlock.Text = string.IsNullOrWhiteSpace(game.Description)
                    ? "Описание отсутствует"
                    : game.Description;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки игры: " + ex.Message);
            }
        }

        private void LoadReviews()
        {
            try
            {
                List<ReviewRow> reviews = Core.Content.Reviews
                    .Where(r => r.GameID == _gameId)
                    .OrderByDescending(r => r.CreatedAt)
                    .Select(r => new ReviewRow
                    {
                        UserFIO = r.AppUser.FIO,
                        AvgRating = r.AvgRating,
                        Gameplay = r.Gameplay,
                        Graphics = r.Graphics,
                        Story = r.Story,
                        Sound = r.Sound,
                        Optimization = r.Optimization,
                        Comment = r.Comment,
                        CreatedAt = r.CreatedAt
                    }).ToList();

                ReviewsDataGrid.ItemsSource = reviews;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки отзывов: " + ex.Message);
            }
        }

        private void CheckExistingReview()
        {
            if (Core.CurrentUser == null)
            {
                SetReviewFormEnabled(false);
                ExistingReviewTextBlock.Text = "Для оценки игры необходимо войти в систему.";
                return;
            }

            bool exists = Core.Content.Reviews.Any(r =>
                r.AppUserID == Core.CurrentUser.ID && r.GameID == _gameId);

            if (exists)
            {
                SetReviewFormEnabled(false);
                ExistingReviewTextBlock.Text = "Вы уже оставили отзыв на эту игру. Повторный отзыв запрещён.";
            }
            else
            {
                SetReviewFormEnabled(true);
                ExistingReviewTextBlock.Text = "Оцените каждый критерий от 1 до 5 и оставьте комментарий.";
            }
        }

        private void SetReviewFormEnabled(bool enabled)
        {
            GameplayComboBox.IsEnabled = enabled;
            GraphicsComboBox.IsEnabled = enabled;
            StoryComboBox.IsEnabled = enabled;
            SoundComboBox.IsEnabled = enabled;
            OptimizationComboBox.IsEnabled = enabled;
            CommentTextBox.IsEnabled = enabled;
            SaveReviewButton.IsEnabled = enabled;
        }

        private void SaveReviewButton_Click(object sender, RoutedEventArgs e)
        {
            if (Core.CurrentUser == null)
            {
                MessageBox.Show("Сначала выполните вход.");
                return;
            }

            if (GameplayComboBox.SelectedItem == null ||
                GraphicsComboBox.SelectedItem == null ||
                StoryComboBox.SelectedItem == null ||
                SoundComboBox.SelectedItem == null ||
                OptimizationComboBox.SelectedItem == null)
            {
                MessageBox.Show("Нельзя пропускать критерии. Выберите оценку от 1 до 5 для каждого пункта.");
                return;
            }

            string comment = CommentTextBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(comment))
            {
                MessageBox.Show("Комментарий обязателен.");
                return;
            }

            if (comment.Length > 1000)
            {
                MessageBox.Show("Комментарий слишком длинный.");
                return;
            }

            int gameplay = (int)GameplayComboBox.SelectedItem;
            int graphics = (int)GraphicsComboBox.SelectedItem;
            int story = (int)StoryComboBox.SelectedItem;
            int sound = (int)SoundComboBox.SelectedItem;
            int optimization = (int)OptimizationComboBox.SelectedItem;

            if (!IsRatingCorrect(gameplay) || !IsRatingCorrect(graphics) ||
                !IsRatingCorrect(story) || !IsRatingCorrect(sound) ||
                !IsRatingCorrect(optimization))
            {
                MessageBox.Show("Каждая оценка должна быть от 1 до 5.");
                return;
            }

            try
            {
                bool duplicate = Core.Content.Reviews.Any(r =>
                    r.AppUserID == Core.CurrentUser.ID && r.GameID == _gameId);

                if (duplicate)
                {
                    MessageBox.Show("Вы уже оставили отзыв на эту игру.");
                    CheckExistingReview();
                    return;
                }

                decimal avg = Math.Round(
                    (gameplay + graphics + story + sound + optimization) / 5m, 2);

                Review review = new Review
                {
                    AppUserID = Core.CurrentUser.ID,
                    GameID = _gameId,
                    AvgRating = avg,
                    Gameplay = (byte)gameplay,
                    Graphics = (byte)graphics,
                    Story = (byte)story,
                    Sound = (byte)sound,
                    Optimization = (byte)optimization,
                    Comment = comment,
                    CreatedAt = DateTime.Now
                };

                Core.Content.Reviews.Add(review);
                Core.Content.SaveChanges();

                MessageBox.Show("Отзыв сохранён. Итоговая оценка: " + avg.ToString("F2"));
                LoadGame();
                LoadReviews();
                CheckExistingReview();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения отзыва: " + ex.Message);
            }
        }

        private bool IsRatingCorrect(int value)
        {
            return value >= 1 && value <= 5;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new GamesPage());
        }
    }
}
