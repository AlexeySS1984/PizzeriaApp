using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace GameReviewTicket27.Pages
{
    public partial class RegisterPage : Page
    {
        public RegisterPage()
        {
            InitializeComponent();
        }

        private void CreateButton_Click(object sender, RoutedEventArgs e)
        {
            string fio = FioTextBox.Text.Trim();
            string login = LoginTextBox.Text.Trim();
            string password = PasswordBox.Password;
            string repeat = RepeatPasswordBox.Password;

            if (string.IsNullOrWhiteSpace(fio) || string.IsNullOrWhiteSpace(login) ||
                string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(repeat))
            {
                MessageBox.Show("Заполните все обязательные поля.");
                return;
            }

            if (fio.Length < 3)
            {
                MessageBox.Show("ФИО введено некорректно.");
                return;
            }

            if (login.Length < 3)
            {
                MessageBox.Show("Логин должен содержать минимум 3 символа.");
                return;
            }

            if (password.Length < 4)
            {
                MessageBox.Show("Пароль должен содержать минимум 4 символа.");
                return;
            }

            if (password != repeat)
            {
                MessageBox.Show("Пароли не совпадают.");
                return;
            }

            if (BirthdayDatePicker.SelectedDate.HasValue &&
                BirthdayDatePicker.SelectedDate.Value.Date > DateTime.Today)
            {
                MessageBox.Show("Дата рождения не может быть в будущем.");
                return;
            }

            try
            {
                if (Core.Content.AppUsers.Any(u => u.Login == login))
                {
                    MessageBox.Show("Пользователь с таким логином уже существует.");
                    return;
                }

                AppUser user = new AppUser
                {
                    FIO = fio,
                    Birthday = BirthdayDatePicker.SelectedDate,
                    Login = login,
                    Password = password
                };

                Core.Content.AppUsers.Add(user);
                Core.Content.SaveChanges();

                MessageBox.Show("Регистрация выполнена успешно.");
                NavigationService.Navigate(new AuthPage());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить пользователя: " + ex.Message);
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }
    }
}
