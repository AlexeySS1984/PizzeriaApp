using System.Windows;

namespace GameReviewTicket27
{
    public partial class App : Application
    {
    }
}
