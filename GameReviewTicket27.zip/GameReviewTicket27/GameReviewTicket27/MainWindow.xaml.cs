using System.Windows;
using GameReviewTicket27.Pages;

namespace GameReviewTicket27
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MainFrame.Navigate(new AuthPage());
        }
    }
}
