namespace GameReviewTicket27
{
    public static class Core
    {
        // Класс контекста появится после добавления ADO.NET Entity Data Model.
        // Имя БД из скрипта: _Ticket27_GameReviewBD
        public static _Ticket27_GameReviewBDEntities Content =
            new _Ticket27_GameReviewBDEntities();

        public static AppUser CurrentUser { get; set; }
    }
}
